# shopping-cart

## database
- Buat database baru dengan nama <b>shopping-cart</b>
- Import file <b>shopping-cart.sql</b> yang ada dalam folder database

## website:
https://www.plajarikode.com/2020/05/membuat-shopping-cart-dengan-php.html
